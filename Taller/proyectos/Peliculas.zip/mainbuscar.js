searchButton=document.getElementById("searchButton");
searchButton.addEventListener("click", function() {
valorBuscar=document.getElementById("searchInput").value;

peliculas=localStorage.getItem("pelis3");

if(peliculas==null){
    arreglo=[];
}else{
    arreglo=JSON.parse(peliculas);
}
caja=document.getElementById("movieResults");
codigo="";
for(let i=0; i<arreglo.length; i++){
    if(arreglo[i].nombre.toLowerCase()==valorBuscar.toLowerCase()){
        codigo=codigo+`<div><h1>${arreglo[i].nombre}</h1>
        <p>${arreglo[i].genero}</p>
        <p>${arreglo[i].year}</p>
        <p>${arreglo[i].calificacion}</p>
        </div>`;

    }
    }
caja.innerHTML=codigo;

});