boton = document.getElementById("boton");
boton.addEventListener("click", function() {

    peliculas=localStorage.getItem("pelis3");

    if(peliculas==null){
        arreglo=[];
    }else{
        arreglo=JSON.parse(peliculas);
    }

    let nombre=document.getElementById("movieTitle").value;
    let genero=document.getElementById("movieGenre").value;
    let year=document.getElementById("movieYear").value;
    let calificacion=document.getElementById("movieRating").value;


    //Objeto de la nueva película

    arreglo.push({ nombre, genero, year, calificacion });
    localStorage.setItem("pelis3", JSON.stringify(arreglo));
    console.log(arreglo);
});