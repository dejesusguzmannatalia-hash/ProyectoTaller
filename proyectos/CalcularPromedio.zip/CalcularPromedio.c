#include <stdio.h>
int main() {
    float c1, c2, c3, c4, c5;
    float promedio;
    printf("Ingresa la calificacion 1: ");
    scanf("%f", &c1);
    printf("Ingresa la calificacion 2: ");
    scanf("%f", &c2);
    printf("Ingresa la calificacion 3: ");
    scanf("%f", &c3);
    printf("Ingresa la calificacion 4: ");
    scanf("%f", &c4);
    printf("Ingresa la calificacion 5: ");
    scanf("%f", &c5);
    promedio = (c1 + c2 + c3 + c4 + c5) / 5;
    printf("Tu promedio es: %.2f\n", promedio);
    if (promedio <= 5.9) {
        printf("NO APROBADO – SIN DERECHO A FINAL");
    }
    else if (promedio <= 8.0) {
        printf("PRESENTA EXAMEN FINAL");
    }
    else if (promedio <= 9.4) {
        printf("EXENTO SIN REDONDEO EN CALIFICACION");
    }
    else {
        printf("TU CALIFICACION FINAL ES 10");
    }
    return 0;
}




