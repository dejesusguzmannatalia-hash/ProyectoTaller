const gameArea = document.getElementById("gameArea");
const scoreDisplay = document.getElementById("score");
const timeDisplay = document.getElementById("time");
const startBtn = document.getElementById("startBtn");

let score = 0;
let time = 35;
let gameInterval;
let spawnInterval;
let speed = 800;
let maxBugs = 25;

const goodImages = [
  "imagenes/bueno1.png",
  "imagenes/bueno2.png",
  "imagenes/bueno3.png",
  "imagenes/bueno4.png",
  "imagenes/bueno5.png"
];

startBtn.addEventListener("click", startGame);

function startGame() {
  score = 0;
  time = 35;
  speed = 800;

  scoreDisplay.textContent = score;
  timeDisplay.textContent = time;

  gameArea.innerHTML = "";

  gameInterval = setInterval(updateTime, 1000);
  spawnInterval = setInterval(spawnBug, speed);

  startBtn.disabled = true;
}

function updateTime() {
  time--;
  timeDisplay.textContent = time;

  if (time % 5 === 0 && speed > 300) {
    speed -= 100;
    clearInterval(spawnInterval);
    spawnInterval = setInterval(spawnBug, speed);
  }

  if (time <= 0) {
    endGame();
  }
}

function spawnBug() {
  if (gameArea.children.length >= maxBugs) return;

  const bug = document.createElement("div");

  const isBad = Math.random() < 0.3;

  bug.classList.add("bug");

  if (isBad) {
    bug.style.backgroundImage = "url('imagenes/malo.png')";
  } else {
    const randomImage = goodImages[Math.floor(Math.random() * goodImages.length)];
    bug.style.backgroundImage = `url('${randomImage}')`;
  }

  bug.style.backgroundSize = "cover";
  bug.style.backgroundPosition = "center";

  const size = Math.random() * 30 + 40;
  bug.style.width = size + "px";
  bug.style.height = size + "px";

  const x = Math.random() * (gameArea.clientWidth - size);
  const y = Math.random() * (gameArea.clientHeight - size);

  bug.style.left = x + "px";
  bug.style.top = y + "px";

  bug.addEventListener("click", () => {
    if (isBad) {
      score -= 2;
    } else {
      score += 1;
    }

    scoreDisplay.textContent = score;
    bug.remove();
  });

  gameArea.appendChild(bug);
}

function endGame() {
  clearInterval(gameInterval);
  clearInterval(spawnInterval);

  alert("Juego terminado 🕹️\nPuntaje: " + score);

  startBtn.disabled = false;
}